
// Submitted By:
// Jaspreet kaur Student Id: C0709466
//Paramjeet kaur Student Id: C0710778
//Koushal Puliyala Student Id: C0709212

package com.example.macstudent.chitchat;

/**
 * Created by macstudent on 2017-12-05.
 */

public class message {
    public String msg;
    public String d;
     public message(){

     }
     public message(String x, String y){
         this.msg = x ;
         this.d = y ;
     }
     public void setMsg(String x){
         this.msg = x ;

     }
     public void setdate(String y){
         this.msg = y ;

     }

}
